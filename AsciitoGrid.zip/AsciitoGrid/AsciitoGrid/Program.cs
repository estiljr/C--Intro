﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;

namespace AsciitoGrid
{
    class Program
    {
        static void Main(string[] args)
        {
            using (StreamReader sr = new StreamReader("file.txt"))
            {
                string[] line1 = sr.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                int ncols = (Convert.ToInt32(line1[1]));

                string[] line2 = sr.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                int nrows = (Convert.ToInt32(line2[1]));

                string[] line3 = sr.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                double xllcorner = (Convert.ToDouble(line3[1]));

                string[] line4 = sr.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                double yllcorner = (Convert.ToDouble(line4[1]));

                string[] line5 = sr.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                double cellsize = (Convert.ToDouble(line5[1]));

                string[] line6 = sr.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                int nodata = (Convert.ToInt32(line6[1]));

                ArrayList xcoord = new ArrayList();
                IEnumerable<int> x = Enumerable.Range(0, ncols);

                foreach (int column_no in x)
                {
                    xcoord.Add(Convert.ToString(xllcorner + 0.5 * cellsize + column_no * cellsize));
                    // Console.WriteLine(xcoord[column_no]);
                    Console.WriteLine(column_no);
                    xcoord.Clear();

                }
                {
                    Console.WriteLine(ncols); Console.WriteLine(nrows); Console.WriteLine(xllcorner); Console.WriteLine(yllcorner);
                    Console.WriteLine(cellsize); Console.WriteLine(nodata);


                    Console.ReadLine();
                }

                using (StreamWriter textOutput = new StreamWriter("textOutput.txt"))
                {
                    foreach (int column_no in x)
                    {
                        textOutput.WriteLine(column_no);
                    }
                }
            }
        }
    }
}

